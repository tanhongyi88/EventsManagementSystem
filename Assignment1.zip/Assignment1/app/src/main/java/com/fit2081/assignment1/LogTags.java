package com.fit2081.assignment1;

public class LogTags {
    public static String MISSING_SMS = "MISSING_SMS";
}
