package com.fit2081.assignment1;

public class KeyStore {
    // Credentials======================================================
    public static String FILE_NAME = "USER_AUTHENTICATION_FILE";
    public static String KEY_USERNAME = "KEY_USERNAME";
    public static String KEY_PASSWORD = "KEY_PASSWORD";
    // Category=========================================================
    public static String CATEGORY_FILE = "CATEGORY_FILE";
    public static String CATEGORY_ID = "CATEGORY_ID";
    public static String CATEGORY_NAME = "CATEGORY_NAME";
    public static String CATEGORY_EVENT_COUNT = "CATEGORY_EVENT_COUNT";
    public static String IS_CATEGORY_ACTIVE = "IS_CATEGORY_ACTIVE";
    // Event=============================================================
    public static String EVENT_FILE = "EVENT_FILE";
    public static String EVENT_ID = "EVENT_ID";
    public static String EVENT_CATEGORY_ID = "EVENT_CATEGORY_ID";
    public static String EVENT_NAME = "EVENT_NAME";
    public static String EVENT_TICKETS_AVAILABLE = "EVENT_TICKETS_AVAILABLE";
    public static String IS_EVENT_ACTIVE = "IS_EVENT_ACTIVE";


}
